//
//  ViewController.swift
//  ColdCall
//
//  Created by Cleland on 7/16/17. 👽
//  Copyright © 2017 Cleland Austin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

//MARK: Variables
    let namesArray = [
        "Carl Sagan",
        "Ada Lovelace",
        "Albert Einstein",
        "Isaac Newton",
        "Nikola Tesla",
        "Charles Darwin"]
    
//MARK: Outlets
    @IBOutlet var nameLabel: UILabel!

//MARK: Actions
    @IBAction func callButtonPressed(_ sender: UIButton) {
        getNewCaller()
    }
    
//MARK: Custom functions
    func getNewCaller() {
        let randomNumber: Int = Int(arc4random_uniform(UInt32(namesArray.count-1)))
        if (nameLabel.text != namesArray[randomNumber]){
            nameLabel.text = namesArray[randomNumber]
        }
    }
    
//MARK: Bult in functions
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

