// Cleland Austin

let type: String = "Rectangle"
let description: String = "A quadrilateral with four right angles"

var width: Double = 5
var height: Double = 10.5
let area = width * height

height += 1
width += 1

// Note how you can "interpolate" variables into Strings using the following syntax
print("The shape is a \(type) or \(description) with an area of \(area)")
