//
//  ViewController.swift
//  NinjaGold
//
//  Created by cleland on 7/16/17.
//  Copyright © 2017 Cleland Austin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
//MARK: Variables
    var points: Int = 0

//MARK: Outlets
    @IBOutlet var scorelabel: UILabel!
    @IBOutlet var lossAndEarningsLabel: UILabel!
    
//MARK: Actions
    @IBAction func farmButtonPressed(_ sender: UIButton) {
        let coin: Int = Int(arc4random_uniform(11)+10)
        points += coin
        scorelabel.text = String(points)
        lossAndEarningsLabel.text = "Earned \(coin) Gold"
        lossAndEarningsLabel.isHidden = false
    }
    
    @IBAction func caveButtonPressed(_ sender: UIButton) {
        let coin: Int = Int(arc4random_uniform(6)+5)
        points += coin
        scorelabel.text = String(points)
        lossAndEarningsLabel.text = "Earned \(coin) Gold"
        lossAndEarningsLabel.isHidden = false
    }
    
    @IBAction func houseButtonPressed(_ sender: UIButton) {
        let coin:Int = Int(arc4random_uniform(4)+2)
        points += coin
        scorelabel.text = String(points)
        lossAndEarningsLabel.text = "Earned \(coin) Gold"
        lossAndEarningsLabel.isHidden = false
    }
    
    @IBAction func casinoButtonPressed(_ sender: UIButton) {
        let possOrNeg = Int(arc4random_uniform(2))
        let coinValue = Int(arc4random_uniform(50)+1)
        if (possOrNeg == 0) {
            points -= coinValue
            lossAndEarningsLabel.text = "Lost \(coinValue) Gold"
        }else{
            points += coinValue
            lossAndEarningsLabel.text = "Earned \(coinValue) Gold"
        }
        scorelabel.text = String(points)
        lossAndEarningsLabel.isHidden = false
    }
    
    @IBAction func resetButtonPressed(_ sender: UIButton) {
        points = 0
        scorelabel.text = String(points)
    }
    
//MARK: Built in functions
    override func viewDidLoad() {
        super.viewDidLoad()
        lossAndEarningsLabel.isHidden = true
        scorelabel.text = String(points)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

