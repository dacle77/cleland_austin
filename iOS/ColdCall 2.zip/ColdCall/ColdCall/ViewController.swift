//
//  ViewController.swift
//  ColdCall
//
//  Created by Cleland on 7/16/17. 👽
//  Copyright © 2017 Cleland Austin. All rights reserved.
//
//MARK: - COLD CALL V2

import UIKit

class ViewController: UIViewController {

//MARK: Variables
    let namesArray = [
        "Carl Sagan",
        "Ada Lovelace",
        "Albert Einstein",
        "Isaac Newton",
        "Nikola Tesla",
        "Charles Darwin"]
    
//MARK: Outlets
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var numberLabel: UILabel!

//MARK: Actions
    @IBAction func callButtonPressed(_ sender: UIButton) {
        getNewCaller()
        getNewNumber()
    }
    
//MARK: Custom functions
    func getNewCaller() {
        let randomNumber: Int = Int(arc4random_uniform(UInt32(namesArray.count-1)))
        if (nameLabel.text != namesArray[randomNumber]){
            nameLabel.text = namesArray[randomNumber]
        }
    }
    
    func getNewNumber() {
        let randomNumber: Int = Int(arc4random_uniform(5)+1)
        numberLabel.text = String(randomNumber)
        numberLabel.isHidden = false
        
        switch randomNumber {
        case 1,2:
            numberLabel.textColor = .red
        case 3,4:
            numberLabel.textColor = .orange
        case 5:
            numberLabel.textColor = .green
        default:
            break
        }
        
    }
    
//MARK: Bult in functions
    override func viewDidLoad() {
        super.viewDidLoad()
        numberLabel.isHidden = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

